MotoLog Web PWA - Ready to Upload

Upload index.html, manifest.webmanifest, and service-worker.js to the root of your HTTPS host.

GitHub Pages:
1. Create a repository named motolog.
2. Upload all three files to the repository root.
3. Settings > Pages > Deploy from a branch > main > /(root).
4. Open the HTTPS address GitHub provides in Safari.
5. iPhone: Share > Add to Home Screen.
